<?php
require_once '../vendor/autoload.php';

// Retrieve data from the POST request
$admissionNumber = $_POST['admissionNumber'];
$parentPhoneNumber = $_POST['parentPhoneNumber'];
console.log(parentPhoneNumber)
$attendanceReport = $_POST['attendanceReport'];

// Set up Africa's Talking credentials
$username = 'ams_hackathon';
$apiKey = 'e1e336d5ddc2da568c686d51982b859c31f353a4ebc6ff446bce9bf828c91211';

// Initialize Africa's Talking
$africastalking = new Africastalking\SDK\Africastalking($apiKey, $username);

// Initialize SMS service
$sms = $africastalking->sms();

// Set up message options
$options = [
    'to' => $parentPhoneNumber,
    'message' => 'Attendance Report for ' . $admissionNumber . ': ' . $attendanceReport,
];

// Send the SMS
if ($_POST['messaging']){
    try {
        $result = $sms->send($options);
        echo json_encode(['success' => true, 'message' => 'SMS sent successfully']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error sending SMS: ' . $e->getMessage()]);
    }
}

?>
